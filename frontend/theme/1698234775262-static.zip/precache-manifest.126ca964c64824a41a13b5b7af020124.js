self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c692337ebb377b4e26ffc57d9a7d1fea",
    "url": "/index.html"
  },
  {
    "revision": "bb9b2985d292760f5e36",
    "url": "/static/css/main.70506d7c.chunk.css"
  },
  {
    "revision": "003175102ed16b0c8f30",
    "url": "/static/js/2.d5aded0d.chunk.js"
  },
  {
    "revision": "d466ab9648f013dea081956fc7c904f3",
    "url": "/static/js/2.d5aded0d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "30664ee76ff1cdf8cee3",
    "url": "/static/js/3.7570fa4a.chunk.js"
  },
  {
    "revision": "bb9b2985d292760f5e36",
    "url": "/static/js/main.209e3d03.chunk.js"
  },
  {
    "revision": "4ef78b782979c65d64fb",
    "url": "/static/js/runtime-main.70b25b25.js"
  },
  {
    "revision": "8b0039c4cf28b1c61243ecab434ffd61",
    "url": "/static/media/atm-card.8b0039c4.png"
  },
  {
    "revision": "c938f674ea8b0890d5e4c376660d8e42",
    "url": "/static/media/check-mark.c938f674.png"
  },
  {
    "revision": "1696591841484e27681ee4fcb296dda5",
    "url": "/static/media/paypal.16965918.png"
  },
  {
    "revision": "a407467a2ce8074cf6c4261832e17601",
    "url": "/static/media/shopify.a407467a.png"
  }
]);